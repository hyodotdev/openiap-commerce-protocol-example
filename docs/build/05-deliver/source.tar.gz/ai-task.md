# Deliver, retry, deduplicate

Add an HMAC receiver, durable inbox, and bounded retry worker. Exercise 503, reopen the database, retry successfully, then simulate a lost acknowledgement. Redelivery must have one inbox effect.

Use the existing reviewed prototype where it satisfies the installed contract.
Run the backend, inspect the result, correct problems, and rerun the affected check.
Keep all work uncommitted.
