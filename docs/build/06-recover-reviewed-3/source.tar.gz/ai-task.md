# Review the completed backend

Apply the Fable 5.1 max CLI review to the final checkpoint. Add the missing
first-binding grant event in the same transaction as ownership, reject a
premature expiry without consuming its observation, and verify both rollback
and expiry boundaries. Correct test labels to describe what they exercise.

Repair patch generation without rewriting historical source or screenshots.
Build patches from the preceding archived source and verify their hashes.
Install and test each archive outside the monorepo with npm. Capture the revised
final screen on desktop and mobile, then export only matching source evidence.

Keep the original six checkpoints as history. Explain their incomplete discovery
and missing grant behavior; do not describe them as conformant providers. Keep
all changes uncommitted for maintainer review.

Apply the second review: retain gate delivery state for delayed expiry,
retain store occurrence on delayed binding, preserve consecutive failure logs,
and state actual package contents and runtime requirements. Add a ready-to-run
generic event receiver for an existing backend, reusing the same receiver
handler. Demonstrate signed lifecycle ingestion, duplicate delivery, tampering,
and persisted inbox recovery over real local HTTP. Keep all samples fictional.

Add composable integration roles: experience, commerce, and data. Ship a short
AI integration brief and a backend helper that maps Apple/Google OpenIAP
purchase fields into the installed verification schema. Test invalid inputs
and exclude client-supplied identity. Keep paywall UI APIs product-specific,
current IAPKit-only client helpers explicit, and store/device proof separate
from local fixtures. Reuse the existing consumer and contract validators.

The first bridge test failed because store evidence was nested under an extra
`evidence` key. Keep the failure output, use the installed input schema's
top-level `apple`/`google` members, and rerun that boundary check.
