import assert from "node:assert/strict";
import { rmSync } from "node:fs";
import vectors from "openiap-commerce-protocol/vectors/signatures.json";
import { SUBSCRIPTION_STATES, WEBHOOK } from "openiap-commerce-protocol";
import { FIXTURE, isEntitled } from "./provider.mjs";
import { requestOperation } from "./scenario.mjs";
import { startLab } from "./server.mjs";
import { authentic, deliver, sign } from "./webhooks.mjs";

export async function verifyLab({ compareSigner } = {}) {
  const lab = startLab();
  const checks = [];
  const check = (label, actual, expected) => {
    assert.deepEqual(actual, expected, label);
    checks.push(label);
  };
  try {
    for (let i = 0; i < 6; i++) await lab.scenario.advance();
    checks.push(...lab.scenario.history.flatMap((entry) => entry.checks));
    for (const vector of vectors.cases) {
      const signature = sign(vector.secret, vector.timestamp, vector.body);
      const expected = vector.previousSecret
        ? `${signature},${sign(vector.previousSecret, vector.timestamp, vector.body)}`
        : signature;
      check(`Signature vector: ${vector.name}`, expected, vector.expected);
      if (compareSigner) {
        check(
          `IAPKit signs the same bytes: ${vector.name}`,
          signature,
          await compareSigner(vector.secret, vector.timestamp, vector.body),
        );
      }
      check(
        `Receiver accepts vector: ${vector.name}`,
        authentic(
          [vector.secret],
          String(vector.timestamp),
          vector.body,
          vector.presentedHeader ?? expected,
          vector.timestamp,
        ),
        true,
      );
    }
    for (const vector of vectors.rejections) {
      check(
        `Receiver rejects: ${vector.name}`,
        authentic(
          [vector.secret],
          String(vector.timestamp),
          vector.body,
          vector.presentedSignature,
          vector.receiverNow ?? vector.timestamp,
        ),
        false,
      );
    }
    for (const state of [...SUBSCRIPTION_STATES, "FutureState"]) {
      const eligible = state === "Active" || state === "InGracePeriod";
      check(`${state}: before expiry`, isEntitled(state, 100, 99), eligible);
      check(`${state}: at expiry`, isEntitled(state, 100, 100), false);
      check(
        `${state}: no deadline`,
        isEntitled(state, undefined, 100),
        eligible,
      );
    }
    const call = (name, input, role) =>
      requestOperation(lab.runtime.baseUrl, name, input, role);
    check(
      "Missing credentials are refused",
      (await call("entitlements", { userId: FIXTURE.userId }, null)).httpStatus,
      401,
    );
    check(
      "Verification role cannot enumerate users",
      (await call("entitlements", { userId: FIXTURE.userId }, "verification"))
        .httpStatus,
      403,
    );
    check(
      "Malformed input is refused",
      (await call("bindPurchase", { store: FIXTURE.store })).httpStatus,
      400,
    );
    check(
      "A real store is not falsely accepted",
      (
        await call("verifyPurchase", {
          store: "google",
          google: { purchaseToken: "fixture" },
        })
      ).body.error.code,
      "UNSUPPORTED_STORE",
    );
    check(
      "Erasure is explicitly unimplemented",
      (await call("eraseUser", { userId: FIXTURE.userId })).body.error.code,
      "UNSUPPORTED_PROFILE",
    );
    check(
      "Late cancellation cannot reopen expired access",
      lab.runtime.provider.observe({
        id: "late-cancel",
        kind: "cancel",
        occurredAt: FIXTURE.startsAt + 1000,
      }),
      false,
    );
    const body = lab.runtime.provider.db
      .query("SELECT body FROM outbox LIMIT 1")
      .get().body;
    const timestamp = Math.floor(lab.runtime.time / 1000).toString();
    const invalid = await lab.runtime.receiver.fetch(
      new Request(`${lab.runtime.baseUrl}/demo/receiver`, {
        method: "POST",
        body: body + " ",
        headers: {
          [WEBHOOK.timestampHeader]: timestamp,
          [WEBHOOK.signatureHeader]: sign(lab.runtime.secret, timestamp, body),
        },
      }),
    );
    check("Tampered HTTP body has no inbox effect", invalid.status, 401);
    check(
      "Receiver still has exactly three events",
      lab.runtime.receiver.count(),
      3,
    );
    check(
      "Cross-origin demo mutations are refused",
      (
        await fetch(`${lab.runtime.baseUrl}/demo/advance`, {
          method: "POST",
          headers: { origin: "https://untrusted.example" },
        })
      ).status,
      403,
    );
  } finally {
    await lab.close();
    rmSync(lab.directory, { recursive: true, force: true });
  }

  const fresh = startLab();
  try {
    const call = (name, input) =>
      requestOperation(fresh.runtime.baseUrl, name, input);
    const evidence = { store: FIXTURE.store, evidence: FIXTURE.evidence };
    await call("verifyPurchase", evidence);
    const bindings = await Promise.all(
      ["alice", "bob"].map((userId) =>
        call("bindPurchase", { ...evidence, userId }),
      ),
    );
    check(
      "Concurrent ownership claims have one winner",
      bindings.filter((row) => row.body.bound).length,
      1,
    );
    fresh.runtime.time += 1000;
    const observation = {
      id: "atomic-cancel",
      kind: "cancel",
      occurredAt: fresh.runtime.time,
    };
    fresh.runtime.provider.db.exec(
      "CREATE TRIGGER fail_outbox BEFORE INSERT ON outbox BEGIN SELECT RAISE(ABORT, 'injected disk failure'); END;",
    );
    assert.throws(() => fresh.runtime.provider.observe(observation));
    check(
      "Outbox failure rolls back subscription state",
      fresh.runtime.provider.inspect().purchases[0].willRenew,
      1,
    );
    fresh.runtime.provider.db.exec("DROP TRIGGER fail_outbox");
    check(
      "Failed transaction leaves the observation retryable",
      fresh.runtime.provider.observe(observation),
      true,
    );
    for (let attempt = 0; attempt < 3; attempt++) {
      fresh.runtime.time += 120_000;
      await deliver(
        fresh.runtime.provider,
        fresh.runtime.secret,
        fresh.runtime.now,
        async () => new Response(null, { status: 503 }),
      );
    }
    check(
      "Exhausted retries enter dead-letter",
      fresh.runtime.provider.inspect().deliveries[0].status,
      "dead-letter",
    );
  } finally {
    await fresh.close();
    rmSync(fresh.directory, { recursive: true, force: true });
  }
  return checks;
}

if (import.meta.main) {
  const checks = await verifyLab();
  console.log(
    `Commerce Lab: ${checks.length} checks passed. No store or production service contacted.`,
  );
}
