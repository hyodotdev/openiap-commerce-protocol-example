import assert from "node:assert/strict";
import { operation, validate } from "./contract.mjs";
import { CREDENTIALS, FIXTURE } from "./provider.mjs";

export const STAGES = [
  {
    "title": "Start with the contract",
    "built": "HTTP routes + schema validation + SQLite",
    "result": "A running server, an empty purchase table, and no access."
  }
];

export async function requestOperation(baseUrl, name, input, role = "server") {
  const spec = operation(name);
  const url = new URL(spec.path, baseUrl);
  if (spec.method === "GET" && input)
    for (const [key, value] of Object.entries(input))
      url.searchParams.set(key, value);
  const response = await fetch(url, {
    method: spec.method,
    headers: {
      "content-type": "application/json",
      ...(role ? { authorization: CREDENTIALS[role] } : {}),
    },
    ...(spec.method === "POST" ? { body: JSON.stringify(input) } : {}),
  });
  return {
    operation: name,
    httpStatus: response.status,
    body: await response.json(),
  };
}

export function createScenario(runtime) {
  const history = [];
  const checks = [];
  const evidence = { store: FIXTURE.store, evidence: FIXTURE.evidence };
  const call = (name, input, role) =>
    requestOperation(runtime.baseUrl, name, input, role);
  const check = (label, actual, expected) => {
    assert.deepEqual(actual, expected, label);
    checks.push(label);
  };

  async function advance() {
    const stage = history.length;
    if (stage >= STAGES.length) return history.at(-1);
    const responses = [];
    const run = async (name, input, role) => {
      const result = await call(name, input, role);
      responses.push(result);
      return result;
    };
    const start = checks.length;
    if (stage === 0) {
      check("Fixture request matches the installed schema", validate(operation("verifyPurchase").input, evidence), true);
      check(
        "Discovery remains unsupported until an event can be emitted",
        (await run("providerCapabilities", null, null)).httpStatus,
        501,
      );
      check("Purchase storage starts empty", runtime.provider.inspect().purchases, []);
      check("Unready discovery returns a portable error", (await run("providerCapabilities", null, null)).body.error.code, "UNSUPPORTED_PROFILE");
    }
    const entry = {
      step: stage + 1,
      ...STAGES[stage],
      simulatedTime: new Date(runtime.time).toISOString(),
      ...runtime.provider.inspect(),
      inboxCount: 0,
      responses,
      checks: checks.slice(start),
      totalChecks: checks.length,
    };
    history.push(entry);
    return entry;
  }

  return { advance, history };
}
