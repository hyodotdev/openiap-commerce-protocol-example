# Expire access and restart

Add expiry observations and recovery checks. Recheck access at the exact deadline before a notification arrives. Prove duplicate and late observations cannot reopen access. Review the full implementation and repeat failing checks after every correction.

Use the existing reviewed prototype where it satisfies the installed contract.
Run the backend, inspect the result, correct problems, and rerun the affected check.
Keep all work uncommitted.
