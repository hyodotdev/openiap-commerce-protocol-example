import assert from 'node:assert/strict';
import { test } from 'node:test';
import { mkdirSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createPatch } from './checkpoint-tools.mjs';

test('patches preserve path-like source text across additions, changes, and deletions', () => {
  const temp = mkdtempSync(join(tmpdir(), 'commerce-patch-test-'));
  try {
    const before = join(temp, 'before'), after = join(temp, 'after');
    mkdirSync(before); mkdirSync(after);
    writeFileSync(join(after, 'capture.mjs'), "const paths = ['a/before/', 'b/after/'];\n");
    assert.match(createPatch(before, after), /\+const paths = \['a\/before\/', 'b\/after\/'\];/);
    writeFileSync(join(before, 'capture.mjs'), 'old\n');
    writeFileSync(join(before, 'removed.md'), 'remove\n');
    assert.match(createPatch(before, after), /deleted file mode/);
  } finally { rmSync(temp, { recursive: true, force: true }); }
});
