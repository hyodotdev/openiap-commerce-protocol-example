# Connect it to a user

Add server-only ownership binding, subscription status, and entitlement reads. Verify the same owner can repeat a bind, another owner cannot take it, and verification credentials cannot bind. Show Alice gaining Premium.

Use the existing reviewed prototype where it satisfies the installed contract.
Run the backend, inspect the result, correct problems, and rerun the affected check.
Keep all work uncommitted.
