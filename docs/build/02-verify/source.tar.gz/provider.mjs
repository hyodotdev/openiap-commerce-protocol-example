import { Database } from "bun:sqlite";
import { createHash, randomUUID } from "node:crypto";
import {
  providerCapabilitiesSchema,
  COMMERCE_EVENT_VERSION,
  HTTP_BINDING,
} from "openiap-commerce-protocol";
import { protocolError, validate } from "./contract.mjs";

export const FIXTURE = Object.freeze({
  store: "fixture",
  evidence: "local-purchase-alice",
  userId: "demo_alice",
  productId: "premium.monthly",
  startsAt: Date.UTC(2026, 8, 7, 9),
  expiresAt: Date.UTC(2026, 9, 7, 9),
});
export const CREDENTIALS = Object.freeze({
  verification: "Bearer local-demo-verification",
  server: "Bearer local-demo-server",
});
const fingerprint = (value) => createHash("sha256").update(value).digest("hex");

export function isEntitled(state, expiresAt, now) {
  return (
    (state === "Active" || state === "InGracePeriod") &&
    (expiresAt == null || now < expiresAt)
  );
}

// This adapter recognizes one fictional purchase; it never contacts a store.
function verifyFixture(input) {
  if (input.store !== FIXTURE.store) return { error: "UNSUPPORTED_STORE" };
  if (typeof input.evidence !== "string") return { error: "INVALID_REQUEST" };
  if (input.evidence === "local-upstream-outage") {
    return { error: "VERIFICATION_FAILED" };
  }
  return { accepted: input.evidence === FIXTURE.evidence };
}

export function createProvider(path, now) {
  const db = new Database(path, { create: true });
  db.exec(`
    PRAGMA journal_mode = WAL;
    CREATE TABLE IF NOT EXISTS purchases (
      fingerprint TEXT PRIMARY KEY, user_id TEXT, product_id TEXT NOT NULL,
      state TEXT NOT NULL, expires_at INTEGER NOT NULL, will_renew INTEGER NOT NULL,
      observed_at INTEGER NOT NULL
    );
  `);

  function snapshot(row) {
    return {
      productId: row.product_id,
      state: row.state,
      active: isEntitled(row.state, row.expires_at, now()),
      store: FIXTURE.store,
      expiresAt: row.expires_at,
      willRenew: Boolean(row.will_renew),
    };
  }

  function rowsFor(userId) {
    return db.query("SELECT * FROM purchases WHERE user_id = ?").all(userId);
  }

  function entitlements(userId) {
    const subscriptions = rowsFor(userId)
      .map(snapshot)
      .filter((row) => row.active);
    return {
      userId,
      productIds: [...new Set(subscriptions.map((row) => row.productId))],
      subscriptions,
    };
  }

  const handlers = {
    verifyPurchase(input) {
      const verdict = verifyFixture(input);
      if (verdict.error) return verdict;
      if (verdict.accepted) {
        db.query(
          `INSERT OR IGNORE INTO purchases VALUES (?, NULL, ?, 'Active', ?, 1, ?)`,
        ).run(
          fingerprint(input.evidence),
          FIXTURE.productId,
          FIXTURE.expiresAt,
          FIXTURE.startsAt,
        );
      }
      return {
        store: FIXTURE.store,
        isValid: verdict.accepted,
        state: verdict.accepted ? "ENTITLED" : "INAUTHENTIC",
        ...(verdict.accepted ? { productId: FIXTURE.productId } : {}),
        environment: "local-fixture",
      };
    },
  };

  async function fetch(request) {
    const url = new URL(request.url);
    const spec = HTTP_BINDING.operations.find(
      (entry) => entry.path === url.pathname && entry.method === request.method,
    );
    if (!spec) return protocolError("NOT_FOUND");
    const auth = request.headers.get("authorization");
    if (spec.auth !== "none") {
      if (!Object.values(CREDENTIALS).includes(auth))
        return protocolError("UNAUTHORIZED");
      if (spec.auth === "server" && auth !== CREDENTIALS.server)
        return protocolError("FORBIDDEN");
    }
    if (!handlers[spec.name]) return protocolError("UNSUPPORTED_PROFILE");
    let input = null;
    if (spec.input) {
      try {
        input =
          request.method === "GET"
            ? Object.fromEntries(url.searchParams)
            : await request.json();
      } catch {
        return protocolError("INVALID_REQUEST");
      }
      if (!validate(spec.input, input)) return protocolError("INVALID_REQUEST");
    }
    try {
      const result = handlers[spec.name](input);
      if (result.error) return protocolError(result.error);
      if (!validate(spec.result, result))
        throw new Error("Invalid protocol response");
      return Response.json(result, { status: spec.successStatus });
    } catch {
      return protocolError("INTERNAL_ERROR");
    }
  }

  function inspect() {
    return {
      purchases: db
        .query(
          "SELECT user_id AS userId, product_id AS productId, state, will_renew AS willRenew FROM purchases",
        )
        .all(),
      access: entitlements(FIXTURE.userId),
      deliveries: [],
    };
  }

  return { db, fetch, inspect, close: () => db.close() };
}
