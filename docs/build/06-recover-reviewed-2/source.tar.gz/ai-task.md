# Review the completed backend

Apply the Fable 5.1 max CLI review to the final checkpoint. Add the missing
first-binding grant event in the same transaction as ownership, reject a
premature expiry without consuming its observation, and verify both rollback
and expiry boundaries. Correct test labels to describe what they exercise.

Repair patch generation without rewriting historical source or screenshots.
Build patches from the preceding archived source and verify their hashes.
Install and test each archive outside the monorepo with npm. Capture the revised
final screen on desktop and mobile, then export only matching source evidence.

Keep the original six checkpoints as history. Explain their incomplete discovery
and missing grant behavior; do not describe them as conformant providers. Keep
all changes uncommitted for maintainer review.

Apply the second review: retain gate delivery state for delayed expiry,
retain store occurrence on delayed binding, preserve consecutive failure logs,
and state actual package contents and runtime requirements. Add a ready-to-run
generic event receiver for an existing backend, reusing the same receiver
handler. Demonstrate signed lifecycle ingestion, duplicate delivery, tampering,
and persisted inbox recovery over real local HTTP. Keep all samples fictional.
