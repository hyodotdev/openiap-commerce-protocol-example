import assert from "node:assert/strict";
import { rmSync } from "node:fs";
import { startLab } from "./server.mjs";
import { STAGES, requestOperation } from "./scenario.mjs";

export async function verifyLab() {
  const lab = startLab();
  const checks = [];
  const check = (label, actual, expected) => {
    assert.deepEqual(actual, expected, label);
    checks.push(label);
  };
  try {
    for (const stage of STAGES) await lab.scenario.advance();
    checks.push(...lab.scenario.history.flatMap(entry => entry.checks));
    const unsupported = "bindPurchase";
    const response = await requestOperation(lab.runtime.baseUrl, unsupported, {});
    check("An unimplemented operation is explicitly refused", response.body.error.code, "UNSUPPORTED_PROFILE");
    check("Untrusted browser origins are refused", (await fetch(lab.runtime.baseUrl + "/demo/advance", { method: "POST", headers: { origin: "https://untrusted.example" } })).status, 403);
    return checks;
  } finally {
    await lab.close();
    rmSync(lab.directory, {recursive:true, force:true});
  }
}
if (import.meta.main) {
  const checks = await verifyLab();
  console.log(JSON.stringify({passed: checks.length, checks}, null, 2));
}
