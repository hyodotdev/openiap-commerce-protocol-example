# Handle cancellation

Add cancellation observations and a transactional event outbox. A cancellation stops renewal but preserves the paid period. Do not add delivery until its own milestone.

Use the existing reviewed prototype where it satisfies the installed contract.
Run the backend, inspect the result, correct problems, and rerun the affected check.
Keep all work uncommitted.
