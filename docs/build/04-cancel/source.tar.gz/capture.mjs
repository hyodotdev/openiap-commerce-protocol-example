import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { existsSync, mkdirSync, readFileSync, writeFileSync, readdirSync, cpSync, rmSync } from 'node:fs';
import { join } from 'node:path';
import { chromium } from '@playwright/test';
import { startLab } from './server.mjs';
import { verifyLab } from './verify.mjs';
import { STAGES } from './scenario.mjs';

const root = import.meta.dir;
const checkpoint = JSON.parse(readFileSync(join(root, 'checkpoint.json'), 'utf8'));
const output = join(root, 'docs/build', checkpoint.id);
mkdirSync(output, { recursive: true });
assert(!existsSync(join(output, 'run.json')), 'Checkpoint already published; choose a new checkpoint id.');
const attempt = readdirSync(output).filter(name => name.startsWith('attempt-')).length + 1;
const startedAt = new Date().toISOString();
let checks;
try {
  checks = await verifyLab();
  writeFileSync(join(output, `attempt-${attempt}.txt`), JSON.stringify({ startedAt, command: 'npm run capture', verifier: 'verifyLab() (also used by npm test)', passed: checks.length, checks }, null, 2));
} catch (error) {
  writeFileSync(join(output, `attempt-${attempt}.txt`), `${startedAt}\n${error.stack}\n`);
  throw error;
}

const files = readdirSync(root).filter(name => /\.(mjs|html|json|md)$/.test(name) || name === 'LICENSE' || name === '.gitignore');
const cache = join(root, '.build-cache');
const current = join(cache, 'after');
const previous = join(cache, 'before');
mkdirSync(previous, { recursive: true });
rmSync(current, { recursive: true, force: true });
mkdirSync(current, { recursive: true });
for (const name of files) cpSync(join(root, name), join(current, name));
const diff = spawnSync('git', ['diff', '--no-index', '--no-ext-diff', '--', 'before', 'after'], { cwd: cache, encoding: 'utf8', maxBuffer: 10 * 1024 * 1024 });
assert([0, 1].includes(diff.status), diff.stderr);
const patch = diff.stdout.split('\n').map(line => /^(diff --git |--- a\/|\+\+\+ b\/)/.test(line) ? line.replace(/([ab])\/(?:before|after)\//g, '$1/') : line).join('\n');
writeFileSync(join(output, 'changes.patch'), patch);
const archive = spawnSync('tar', ['-czf', join(output, 'source.tar.gz'), '-C', current, ...files]);
assert.equal(archive.status, 0, archive.stderr?.toString());

const lab = startLab();
const browser = await chromium.launch({ channel: 'chrome' });
try {
  const page = await browser.newPage({ viewport: { width: 1280, height: 1000 } });
  const errors = [];
  page.on('pageerror', error => errors.push(error.message));
  await page.goto(lab.runtime.baseUrl, { waitUntil: 'domcontentloaded' });
  for (let step = 1; step <= STAGES.length; step++) {
    await page.getByRole('button', { name: `Run step ${step} →`, exact: true }).click();
    await page.locator('#progress').filter({ hasText: `Milestone ${step} / ${STAGES.length}` }).waitFor();
  }
  assert.deepEqual(errors, []);
  assert.equal(await page.locator('#error').textContent(), '');
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth > innerWidth), false);
  const responses = page.locator('#responses details');
  if (await responses.count()) {
    const wasOpen = (await responses.last().getAttribute('open')) !== null;
    if (wasOpen) await responses.last().locator('summary').click();
    assert.equal(await responses.last().getAttribute('open'), null);
    await responses.last().locator('summary').click();
    assert.equal(await responses.last().getAttribute('open'), '');
    assert(await responses.last().locator('pre').isVisible());
    if (!wasOpen) await responses.last().locator('summary').click();
  }
  await page.screenshot({ path: join(output, 'screen.png'), fullPage: true });
  await page.setViewportSize({ width: 390, height: 844 });
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth > innerWidth), false);
  await page.screenshot({ path: join(output, 'mobile.png'), fullPage: true });
  const history = lab.scenario.history;
  const record = {
    ...checkpoint,
    startedAt,
    recordedAt: new Date().toISOString(),
    packageVersion: JSON.parse(readFileSync(join(root, 'node_modules/@hyodotdev/openiap-commerce-protocol/package.json'), 'utf8')).version,
    task: readFileSync(join(root, 'ai-task.md'), 'utf8'),
    sourceHashes: Object.fromEntries(files.map(name => [name, createHash('sha256').update(readFileSync(join(current, name))).digest('hex')])),
    checks,
    history,
    screenshot: 'screen.png',
    scope: 'Incremental source checkpoint adapted from the reviewed Commerce Lab prototype. HTTP and SQLite execute locally; store and clock are fixtures. No full profile claim.',
  };
  writeFileSync(join(output, 'run.json'), JSON.stringify(record, null, 2) + '\n');
  rmSync(previous, { recursive: true, force: true });
  cpSync(current, previous, { recursive: true });
  console.log(`Captured ${checkpoint.id}: ${checks.length} checks, ${files.length} source files.`);
} catch (error) {
  writeFileSync(join(output, `browser-failure-${attempt}.txt`), `${new Date().toISOString()}\n${error.stack}\n`);
  throw error;
} finally {
  await browser.close();
  await lab.close();
  rmSync(lab.directory, { recursive: true, force: true });
}
