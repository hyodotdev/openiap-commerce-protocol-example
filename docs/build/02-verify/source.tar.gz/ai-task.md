# Verify a purchase

Add a fictional store adapter and verification. Persist accepted evidence without granting access. Invalid evidence must be a negative verdict; an upstream outage must be an error. Prove that binding is still unimplemented.

Use the existing reviewed prototype where it satisfies the installed contract.
Run the backend, inspect the result, correct problems, and rerun the affected check.
Keep all work uncommitted.
