# Start with the contract

Install the published contract in an independent project. Add capabilities, request/response validation, local HTTP inspection, and SQLite. Return UNSUPPORTED_PROFILE for operations that have not been implemented. Do not claim profile conformance.

Use the existing reviewed prototype where it satisfies the installed contract.
Run the backend, inspect the result, correct problems, and rerun the affected check.
Keep all work uncommitted.
