# OpenIAP Commerce Protocol example

Build a small purchase-to-access backend with AI, one working milestone at a
time. Each checkpoint includes the task, source changes, executed checks, and
a screenshot of that version running.

## Run

Use your favorite package manager to install dependencies:

```sh
npm install # or pnpm install, yarn install, bun install
npm test
npm start
```

This example uses the Bun runtime for HTTP and SQLite. Its scripts work through
any package manager with Bun installed. The protocol can be implemented in your
own language and stack. Open http://127.0.0.1:5181 and run each available step.

## Connect your product

Start with [INTEGRATE.md](INTEGRATE.md) to build a paywall integration, a commerce
service, an event consumer, or an integrated platform. Run `npm run demo:bridge`
to check Apple/Google OpenIAP purchase fields against the installed verification
input schema. The helper runs on the app backend; it does not perform a mobile
purchase or authenticate evidence.

## Receive events in an existing backend

The ready receiver verifies signatures and saves each event once in SQLite.
Run the complete local integration check:

```sh
npm run demo:consumer
```

It sends purchase, renewal, cancellation, expiry, refund, and entitlement
samples over HTTP, retries each delivery, rejects tampering, and reopens the
inbox. No store adapter or provider backend is needed. The inbox stores the
signed event unchanged for your existing processing pipeline.

To run the receiver continuously, set `COMMERCE_WEBHOOK_SECRET` to your
provider's signing secret and run `npm run consumer`. It listens at
`http://127.0.0.1:5182/webhooks/commerce`, with storage in `consumer.sqlite`
(or `COMMERCE_INBOX_PATH`). It is bound to loopback: an HTTPS reverse proxy
must forward to that local address, preserving the exact body bytes. Configure
one emitter/project and signing key per receiver database. Keep the inbox file
on persistent storage. `webhooks.mjs` exports the same Fetch-compatible receiver
handler for embedding in an existing server.

The local check proves ingestion, not store authenticity or financial analytics.
Transaction and price fields are optional; missing values are unknown. A
lifecycle event is not necessarily a new charge. Keep your own revenue and
accounting rules; the receiver preserves the provider's fields without inventing
a zero price or counting every lifecycle event as revenue.

## Build with AI

Give [BUILD.md](BUILD.md) to your AI. Ask it to add one milestone, run it, inspect
the actual screen and responses, fix any issue, and repeat the failed check.
Review the result before moving to the next milestone.

[docs/build](docs/build) records this development run. Every source archive is
an independently runnable checkpoint. Later functionality is absent from the
earlier source, rather than hidden behind a runtime step switch. The dashboard
replays the operations implemented at that checkpoint.

This implementation extends an earlier internal prototype, called Commerce Lab,
which this standalone repository replaces. It is an incremental implementation record, not a claim that an
AI produced the backend in one prompt without reference code.

## Scope

The HTTP requests, SQLite writes, ownership rules, HMAC signatures, delivery
retries, and database recovery are real local operations. The store, user, and
clock are fixtures. No real purchases or credentials are needed. Recovery
reopens both databases inside the same HTTP process; it does not test an OS
crash, process startup, or recovery of externally stored secrets.

This is an educational Commerce Protocol example. Real store validation, login, erasure, tenant isolation, GraphQL,
public HTTPS delivery, and full profile conformance remain separate work.

## Record another checkpoint

Recording needs Node.js with npm, Git, tar, and Google Chrome in addition to
Bun. The backend's test/start scripts use Bun only. `npm run test:tooling`
checks capture tooling separately.

Update `ai-task.md` with the task and review notes. Run `npm test`, inspect the
dashboard, then `npm run capture` with Google Chrome installed. Capture runs the
checks again and preserves failed attempts. Capture installs and tests the archived source in a temporary project, then
checks the desktop and mobile screens. `checkpoint.json.previous` names the
preceding archive, so patch generation also works after a fresh clone. Run
`npm run verify:checkpoints` to check all archived sources and patches from an
empty directory and save the npm execution evidence. Published source
checkpoints are immutable;
use a new directory name in `checkpoint.json` for another revision.
