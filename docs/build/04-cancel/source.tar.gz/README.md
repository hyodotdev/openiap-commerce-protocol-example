# OpenIAP Commerce Protocol example

Build a small purchase-to-access backend with AI, one working milestone at a
time. Each checkpoint includes the task, source changes, executed checks, and
a screenshot of that version running.

## Run

Use your favorite package manager to install dependencies:

```sh
npm install # or pnpm install, yarn install, bun install
npm test
npm start
```

This example uses the Bun runtime for HTTP and SQLite. Its scripts work through
any package manager with Bun installed. The protocol can be implemented in your
own language and stack. Open http://127.0.0.1:5181 and run each available step.

## Build with AI

Give [BUILD.md](BUILD.md) to your AI. Ask it to add one milestone, run it, inspect
the actual screen and responses, fix any issue, and repeat the failed check.
Review the result before moving to the next milestone.

[docs/build](docs/build) records this development run. Every source archive is
an independently runnable checkpoint. Later functionality is absent from the
earlier source, rather than hidden behind a runtime step switch. The dashboard
replays the operations implemented at that checkpoint.

This implementation extracts and extends the previously tested OpenIAP Commerce
Lab prototype. It is an incremental implementation record, not a claim that an
AI produced the backend in one prompt without reference code.

## Scope

The HTTP requests, SQLite writes, ownership rules, HMAC signatures, delivery
retries, and database recovery are real local operations. The store, user, and
clock are fixtures. No real purchases or credentials are needed.

This is an educational part of the IAPKit architecture, not a production
provider. Real store validation, login, erasure, tenant isolation, GraphQL,
public HTTPS delivery, and full profile conformance remain separate work.

## Record another checkpoint

Update `ai-task.md` with the task and review notes. Run `npm test`, inspect the
dashboard, then `npm run capture` with Google Chrome installed. Capture runs the
checks again and preserves failed attempts. Published checkpoints are immutable;
use a new directory name in `checkpoint.json` for another revision.
